<?php
$database= mysqli_connect('localhost','root','','nopakentung');

function query ($query){
     global $database;
    $tampilkan = mysqli_query ($database,$query);
    $wadahkosong = [];
    while($data = mysqli_fetch_assoc ($tampilkan)){
        $wadahkosong [] = $data;
    }
    return $wadahkosong;
}

function tambah1 ($data){
    global $database;
    $nama = $_POST ["nama"];
    $nama = $_POST ["jenis_kelamin"];
    $umur = $_POST ["umur"];
    $kelas = $_POST ["kelas"];
    $no_hp = $_POST ["no_hp"];
    $tanggal_lahir = $_POST ["tanggal_lahir"];
    $pengalaman = $_POST ["pengalaman"];
    $hobi = $_POST ["hobi"];
    $alamat = $_POST ["alamat"];
    $skill = $_POST ["skill"];
    $pendidikan = $_POST ["pendidikan"];
    $nama = $_POST ["pekerjaan"];
    $tambah = "INSERT INTO nopa VALUE
    ('','$nama','$jenis_kelamin','$umur','$kelas','$no_hp','$tanggal_lahir','$pengalaman','$hobi','$alamat','$skill','$pendidikan','$pekerjaan')";

    mysqli_query($database,$tambah);
    return mysqli_affected_rows($database);
}


function hapus ($hapus){
    global $database;
    mysqli_query ($database, "DELETE FROM nopa where no=$hapus");
    return mysqli_affected_rows($database);
}

 
?>